# TestBTC
TestBTC
$ pkg update && pkg upgrade
$ pkg install python git unzip
$ git clone https://github.com/AhrimanSefid/TestBTC
$ cd TestBTC
$ unzip TestBTC.zip
$ cd TestBTC
$ pip install -r requirements.txt
$ python main.py +98